package net.minecraft.client.gui.layouts;

import java.util.function.Consumer;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public interface LayoutElement {
    void setX(int p_265236_);

    void setY(int p_265404_);

    int getX();

    int getY();

    int getWidth();

    int getHeight();

    default ScreenRectangle getRectangle() {
        return new ScreenRectangle(this.getX(), this.getY(), this.getWidth(), this.getHeight());
    }

    default void setPosition(int p_265617_, int p_265577_) {
        this.setX(p_265617_);
        this.setY(p_265577_);
    }

    void visitWidgets(Consumer<AbstractWidget> p_265082_);
}
